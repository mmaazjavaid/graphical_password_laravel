
<?php $__env->startSection('content'); ?> --}}


    <!--  <div class="row-4 ">-->
    <!--      <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#login_modal">-->
    <!--        Login-->
    <!--      </button>-->
    <!--      <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">-->
    <!--        Register-->
    <!--      </button>-->
    <!--</div>-->
    
    







  <!-- Modal -->
  
          
        



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\last attemp\graphicalpassword\resources\views/password/index.blade.php ENDPATH**/ ?>
Hello <strong><?php echo e($username); ?></strong>,
<p><?php echo e($body); ?></p>

<a href="<?php echo e(route('select.password',[
            'username' => $username,
            'email' => $email,
            'address' => $address,
            'city' => $city,
            'contact_num' => $contact_num,
            'deluser'=>'1'
    ])); ?>">Reset password</a>


<?php /**PATH C:\xampp\htdocs\last attemp\graphicalpassword\resources\views/emails/reminder.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css">
  <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Star Admin2 </title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="../../vendors/feather/feather.css">
  <link rel="stylesheet" href="../../vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="../../vendors/ti-icons/css/themify-icons.css">
  <link rel="stylesheet" href="../../vendors/typicons/typicons.css">
  <link rel="stylesheet" href="../../vendors/simple-line-icons/css/simple-line-icons.css">
  <link rel="stylesheet" href="../../vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="../../css/vertical-layout-light/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="../../images/favicon.png" />
</head>

<body>
  <div class="container-scroller">
    <!-- partial:../../partials/_navbar.html -->
    <nav class="navbar default-layout col-lg-12 col-12 p-0 fixed-top d-flex align-items-top flex-row">
      <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-start">
        <div class="me-3">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-bs-toggle="minimize">
            <span class="icon-menu"></span>
          </button>
        </div>
        <div>
          <a class="navbar-brand brand-logo" href="#">
            
            <h3 >Novel graphical password</h3>
          </a>
          <a class="navbar-brand brand-logo-mini" href="#">
            
            <h3 >Novel graphical password</h3>
          </a>
        </div>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-top"> 
        <ul class="navbar-nav">
          <li class="nav-item font-weight-semibold d-none d-lg-block ms-0">
            <h1 class="welcome-text">Good Morning, <span class="text-black fw-bold"> Employee</span></h1>
            <h3 class="welcome-sub-text">Your app  summary this week </h3>
          </li>
        </ul>
        
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-bs-toggle="offcanvas">
          <span class="mdi mdi-menu"></span>
        </button>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:../../partials/_settings-panel.html -->
      
      
          <!-- chat tab ends -->
        
      <!-- partial -->
      <!-- partial:../../partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          
          
          <li class="nav-item nav-category">Manage</li>
          <li class="nav-item">
            <a class="nav-link"  href="/employee/users" aria-expanded="false" aria-controls="tables">
              <i class="menu-icon mdi mdi-table"></i>
              <span class="menu-title">Users Table</span>
              <i class="menu-arrow"></i>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link"  href="/employee/images" aria-expanded="false" aria-controls="tables">
              <i class="menu-icon mdi mdi-table"></i>
              <span class="menu-title">Password images</span>
              <i class="menu-arrow"></i>
            </a>
          </li>
         
        </ul>
      </nav>


<div class="main-panel">
    <div class="content-wrapper">
      <div class="row">
<div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
          <div class="row">

            <div class="pl-3 pt-2 col-10">
                <h4 class="card-title">Users Management</h4>
            </div>
            
          </div>
        
       
        <div class="table-responsive pt-3">
          <table class="table table-bordered">
            <thead>
                
              <tr>
                <th style="width: 10%;" >
                    id
                </th>
                <th style="width: 15%;">
                  Username
                </th>
                <th>
                  Email
                </th>
                <th>
                  Address
                </th>
                <th>
                  City
                </th>
                <th>
                  Phone
                </th>
                <th>
                    Actions
                </th>
                
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $employee_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                      <?php echo e($employee_user->id); ?>

                    </td>
                    <td>
                      <?php echo e($employee_user->username); ?>

                    </td>
                    <td>
                      <?php echo e($employee_user->email); ?>

                    </td>
                    <td>
                      <?php echo e($employee_user->address); ?>

                    </td>
                    <td>
                      <?php echo e($employee_user->city); ?>

                    </td>
                    <td>
                        <?php echo e($employee_user->contact_num); ?>

                      </td>
                      <td>
                        <a href="<?php echo e(route('delete.user',['id'=>$employee_user->id])); ?>" 
                            onclick="event.preventDefault();
                                                                   document.getElementById('update-form').submit();"
                            class="dropdown-item"><i class="fas fa-trash-alt text-warning" style="font-size: 20px;"></i></a>
                                      <form id="update-form" action="<?php echo e(route('delete.user',['username'=>$employee_user->username,'email'=>$employee_user->email])); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                      </form>
                      </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
              
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
</div>



      
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="../../vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page -->
  <script src="../../vendors/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
  <!-- End plugin js for this page -->
  <!-- inject:js -->
  <script src="../../js/off-canvas.js"></script>
  <script src="../../js/hoverable-collapse.js"></script>
  <script src="../../js/template.js"></script>
  <script src="../../js/settings.js"></script>
  <script src="../../js/todolist.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <!-- End custom js for this page-->
</body>

</html>
<?php /**PATH C:\xampp\htdocs\last attemp\graphicalpassword\resources\views/employee/users.blade.php ENDPATH**/ ?>
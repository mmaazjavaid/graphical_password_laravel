
<?php $__env->startSection('content'); ?>

<div class="container">
  <div class="row row-12 ">
    <div class="col-md-6 pb-3">
      <strong> <h3>Select five images as your password</h3></strong>
     </div>
     
 <div class="col-md-3 pr-3 pb-3">
      <a  href="/rejected_user"   class="btn btn-danger"  >
        Return back to signup
      </a>
     </div>
     <div class="col-md-1 pr-3 pb-3">
      <a  href="/selection/reset"   class="btn btn-warning"  >
        Reset
      </a>
     </div>
     
     <?php if($submit_button=='on'): ?>
     <div class="col-md-1 pr-3 pb-3">
      <a  href="/submit/selection"   class="btn btn-success"  >
        Submit
     </a>
     </div>
     <?php else: ?>
     <div class="col-md-1 pr-3 pb-3">
      <a  href="#"   class="btn btn-light"  >
        Submit
     </a>
     </div>
     <?php endif; ?>
     
  
    
</div>
    <div class="row row-cols-6 pt-3">
      <?php 
      foreach ($users as $key => $user) { 
        ?>


<?php if($submit_button=='on'): ?>
<div class="col pb-5">
  
  <a href="#" 
  ><img  <?php if(($user->selected_image)=='1'): ?>
    style=" border: 5px solid#4863A0; width:100px ;height:100px;"
  <?php else: ?>
  style="  width:100px ;height:100px;"   
  <?php endif; ?>  src="/images/<?php echo $user->img ?>" alt="" srcset=""></a>
 
</div>
<?php else: ?>
<div class="col pb-5">
  
  <a href="<?php echo e(route('newuser.store_user',
  [
  'username' => $username,
  'email' => $email,
  'address' => $address,
  'city' => $city,
  'contact_num' => $contact_num,
  'img'=>$user->img
  ])); ?>" 
  ><img  <?php if(($user->selected_image)=='1'): ?>
    style=" border: 5px solid#4863A0; width:100px ;height:100px;"
  <?php else: ?>
  style="  width:100px ;height:100px;"   
  <?php endif; ?>  src="/images/<?php echo $user->img ?>" alt="" srcset=""></a>
 
</div>
<?php endif; ?>









<?php 
} 
?>
        
        
      
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>

  //   $(document).ready(function () {
  //     $(document).on('click','.img', function (e) {
  //         e.preventDefault();
  //         var data={
  //           'img': $(".img:eq(2)").attr('src'),
  //         }
  //         console.log(data);
  //         $.ajaxSetup({
  //       headers: { 'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content') }
  //   });
  //         $.ajax({
  //           type: "POST",
  //           url: "/password_checks",
  //           data:data,
  //           dataType: "json",
  //           success: function (response) {
  //             console.log(response);
  //           }
  //         });
          
  //     });
  // });
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u817397177/domains/link2avicenna.com/public_html/graphicalpassword/resources/views/select.blade.php ENDPATH**/ ?>
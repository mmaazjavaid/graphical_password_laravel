<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Success</title>
</head>
<body>
    <div>
        <h1><?php echo e($message); ?></h1>
        <a href="<?php echo e(route('forgot_pass.user',['incorrect_user'=>$incorrect_user,'username'=>$username])); ?>">forgot password</a>
    </div>
</body>
</html><?php /**PATH /home/u817397177/domains/link2avicenna.com/public_html/graphicalpassword/resources/views/incorrect.blade.php ENDPATH**/ ?>
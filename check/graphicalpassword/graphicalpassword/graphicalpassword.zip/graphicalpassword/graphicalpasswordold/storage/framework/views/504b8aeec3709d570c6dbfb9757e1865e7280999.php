
<?php $__env->startSection('content'); ?>


<form action="<?php echo e(route('forgot_pass.user')); ?>" method="">
    <div class="py-3 form-group">
      <label for="exampleInputEmail1">Email</label>
      <input style="width: 20%"  class="form-control" 
      type="email" class="email" name="email" required>
    </div>    
    <button type="submit" class="btn btn-primary">proceed</button>
  </form>

        
        
      
   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u817397177/domains/link2avicenna.com/public_html/graphicalpassword/resources/views/password/forget.blade.php ENDPATH**/ ?>
Hello <strong><?php echo e($username); ?></strong>,
<p><?php echo e($body); ?></p>

<a href="<?php echo e(route('select.password',[
            'username' => $username,
            'email' => $email,
            'address' => $address,
            'city' => $city,
            'contact_num' => $contact_num,
            'deluser'=>'1'
    ])); ?>">Reset password</a>


<?php /**PATH /home/u817397177/domains/link2avicenna.com/public_html/graphicalpassword/resources/views/emails/reminder.blade.php ENDPATH**/ ?>
@extends('layouts.app')
@section('content')

<div class="container">
  <div class="row-md-6 pb-3">
   <strong> <h3>Select 5 images as your password</h3></strong>
  </div>
    <div class="row row-cols-6 pt-3">
      <?php 
      foreach ($users as $key => $user) { 
        ?>
<div class="col pb-5">
  
    <a href="{{route('newuser.store_user',
    [
    'username' => $username,
    'email' => $email,
    'address' => $address,
    'city' => $city,
    'contact_num' => $contact_num,
    'img'=>$user->img
    ])
    }}" 
    ><img  @if (($user->selected_image)=='1')
      style=" border: 5px solid#4863A0; width:100px ;height:100px;"
    @else
    style="  width:100px ;height:100px;"   
    @endif  src="/images/<?php echo $user->img ?>" alt="" srcset=""></a>
   
</div>
<?php 
} 
?>
        
        
      
    </div>
  </div>

@endsection
@section('scripts')
<script>

  //   $(document).ready(function () {
  //     $(document).on('click','.img', function (e) {
  //         e.preventDefault();
  //         var data={
  //           'img': $(".img:eq(2)").attr('src'),
  //         }
  //         console.log(data);
  //         $.ajaxSetup({
  //       headers: { 'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content') }
  //   });
  //         $.ajax({
  //           type: "POST",
  //           url: "/password_checks",
  //           data:data,
  //           dataType: "json",
  //           success: function (response) {
  //             console.log(response);
  //           }
  //         });
          
  //     });
  // });
</script>
    
@endsection
@extends('layouts.app')
@section('content')


<form action="{{route('forgot_pass.user')}}" method="">
    <div class="py-3 form-group">
      <label for="exampleInputEmail1">Email</label>
      <input style="width: 20%"  class="form-control" 
      type="email" class="email" name="email" required>
    </div>    
    <button type="submit" class="btn btn-primary">proceed</button>
  </form>

        
        
      
   

@endsection
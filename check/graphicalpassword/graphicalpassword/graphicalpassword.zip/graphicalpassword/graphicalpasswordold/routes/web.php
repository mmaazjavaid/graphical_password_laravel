<?php

use App\Http\Controllers\NewuserController;
use \App\Http\Controllers\PasswordCheckController;
use \App\Http\Controllers\PasswordController;
use App\Models\newuser;
use App\Models\password;
use App\Models\password_check;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('password.index');
});
Route::get('/forget',function(){
    return view('password.forget');
});
Route::get('/password/reset',[PasswordController::class,'reset_password'])->name('reset_user.password');
Route::get('/forgot_pass',[PasswordController::class,'forgot_password'])->name('forgot_pass.user');
Route::post('/select_password',[PasswordController::class,'select_password']);
Route::get('/select_password/reset',[PasswordController::class,'select_email_password'])->name('select.password');
Route::get('passwords/show',[PasswordController::class,'index'])->name('passwords.show');
route::get('/newuser',[NewuserController::class,'store'])->name('newuser.store_user');
Route::get('password_checks',[PasswordCheckController::class,'store'])->name('password_checks.store');
Route::get('passwords',[PasswordController::class,'login_page'])->name('login.passwords');
Route::post('passwords/check',[PasswordController::class,'password_check'])->name('passwords.check');
// Route::get('passwords/store_user',[PasswordController::class,'store_user'])->name('password.store_user');
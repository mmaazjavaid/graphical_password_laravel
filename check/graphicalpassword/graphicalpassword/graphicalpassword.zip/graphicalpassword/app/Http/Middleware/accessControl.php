<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class accessControl
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
       
        if (session()->has('password_user')) {
            $data=session('password_user');
            return redirect()->route('passwords.show',[
                'username'=>$data
            ]);
        }
        if(session()->has('username')){
            if(session('username')=='graphicaladmin'){
                return redirect()->route('admin.logins');
            }
            if (session('username')=='graphicalemployee') {
                return redirect()->route('employee.users');
            }
        }else{
            return $next($request);
        }
      
        
    }
}
